﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DIMERCO.B2B.API.Data
{
    class Txt
    {
    }
}
